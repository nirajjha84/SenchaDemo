# module-loader
>Dynamic code loading for modular applications

This package provides a mechanism to load additional code modules at runtime.

Licensed under the same terms as your Ext JS copy.

&copy; 2016 Sencha Inc.