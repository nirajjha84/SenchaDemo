Ext.define('packageApp.view.users.Main', {
    extend : 'Ext.Component',
    xtype  : 'app-users-main',

    html    : 'This is the <strong>users</strong> view!',
    padding : 20
});
