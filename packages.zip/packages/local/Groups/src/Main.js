Ext.define('packageApp.view.groups.Main', {
    extend : 'Ext.Component',
    xtype  : 'app-groups-main',

    html    : 'This is the <strong>groups</strong> view!',
    padding : 20
});
