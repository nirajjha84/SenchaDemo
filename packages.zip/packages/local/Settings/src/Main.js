Ext.define('packageApp.view.settings.Main', {
    extend : 'Ext.Component',
    xtype  : 'app-settings-main',

    html    : 'This is the <strong>settings</strong> view!',
    padding : 20
});
