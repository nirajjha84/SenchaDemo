Ext.define('packageApp.model.Base', {
    extend: 'Ext.data.Model',

    schema: {
        namespace: 'packageApp.model'
    }
});
