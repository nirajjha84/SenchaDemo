Ext.define('packageApp.model.Personnel', {
    extend: 'packageApp.model.Base',

    fields: [
        'name', 'email', 'phone'
    ]
});
