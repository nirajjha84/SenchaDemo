/**
 * This class is the controller for the main view for the application. It is specified as
 * the "controller" of the Main view class.
 */
Ext.define('packageApp.view.main.MainController', {
    extend: 'Ext.app.ViewController',

    alias: 'controller.main',

    requires: [
      'Ext.Package'
    ],

    onItemActivate: function (tabpanel, tab) {
      var pkg = tab.pkg;

      if(pkg) {
        // check incase package is loaded
        if(Ext.Package.isLoaded(pkg)) {
          this.handlePackage(pkg);
        } else {
          tabpanel.setMasked({
            message: 'Loading Package...'
          });

          Ext.Package
              .load(pkg)
              .then(this.handlePackage.bind(this, pkg));
        }
      }
    },

    handlePackage: function(pkg) {
      var tabPanel = this.getView(),
          tab = tabPanel.child('[pkg=' + pkg +']');

      tabPanel.setMasked(null);

      if(!tab.hasPkgItem) {
        tab.hasPkgItem = true;

        tab.add({
          xclass: 'packageApp.view.'+ pkg.toLowerCase() +'.Main'
        })
      }
    },

    onItemSelected: function (sender, record) {
        Ext.Msg.confirm('Confirm', 'Are you sure?', 'onConfirm', this);
    },

    onConfirm: function (choice) {
        if (choice === 'yes') {
            //
        }
    }
});
