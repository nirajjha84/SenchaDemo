/*
 * This file launches the application by asking Ext JS to create
 * and launch() the Application class.
 */
Ext.application({
    extend: 'packageApp.Application',

    name: 'packageApp',

    requires: [
        // This will automatically load all classes in the packageApp namespace
        // so that application classes do not need to require each other.
        'packageApp.*'
    ],

    // The name of the initial view to create.
    mainView: 'packageApp.view.main.Main'
});
